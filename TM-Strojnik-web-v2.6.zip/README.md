# TM-Strojník v2.6

OCR z fotografií:

- velké tlačítko Načíst MTH / km z fotografie
- fotografie displeje se zpracuje přímo v prohlížeči
- rozpoznaná hodnota se před uložením ručně zkontroluje
- načtení účtenky za tankování
- pokus o rozpoznání data, litrů, celkové ceny, ceny za litr a čerpací stanice
- rozpoznané údaje se před uložením zobrazí k opravě
- tankování se po potvrzení uloží ke konkrétní technice

Důležité:
OCR používá Tesseract.js načítaný z internetu. Výsledek závisí na kvalitě fotografie a vždy musí být zkontrolován. OCR není při prvním použití dostupné bez internetu.

Nahraj:
index.html, styles.css, app.js, logo.png, manifest.webmanifest, sw.js.
